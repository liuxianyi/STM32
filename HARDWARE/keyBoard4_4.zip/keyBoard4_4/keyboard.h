#ifndef __keyboad_h__
#define __keyboad_h__
#include "stm32f10x.h"
#include "stdint.h"
#include "delay.h"
#include "oled1.h"
#define val GPIO_ReadInputData(GPIOB);

void Keyspress(void);
void GPIO_Configuration_init(void);
#endif

